#Created by: futuralis.com
mysql -h <host> -u <username> -p'password' -e'show databases' > raw.dbs
echo File generated: raw.dbs